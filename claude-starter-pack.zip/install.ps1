# Claude Code Starter Pack - installer (PowerShell)
$ErrorActionPreference = 'Stop'

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Target    = Join-Path $env:USERPROFILE '.claude'

Write-Host "==> Installing Claude Code Starter Pack to: $Target"

if (-not (Test-Path $Target)) {
    New-Item -ItemType Directory -Path $Target | Out-Null
}

# Backup existing CLAUDE.md
$ExistingClaudeMd = Join-Path $Target 'CLAUDE.md'
if (Test-Path $ExistingClaudeMd) {
    $Ts     = Get-Date -Format 'yyyyMMdd_HHmmss'
    $Backup = Join-Path $Target "CLAUDE.md.backup.$Ts"
    Copy-Item -Path $ExistingClaudeMd -Destination $Backup -Force
    Write-Host "    backed up existing CLAUDE.md -> $Backup"
}

# Install new CLAUDE.md
Copy-Item -Path (Join-Path $ScriptDir 'CLAUDE.md') -Destination $ExistingClaudeMd -Force
Write-Host "    installed CLAUDE.md"

# Install skills (merge-overwrite)
$SkillsTarget = Join-Path $Target 'skills'
if (-not (Test-Path $SkillsTarget)) {
    New-Item -ItemType Directory -Path $SkillsTarget | Out-Null
}
$SkillsSource = Join-Path $ScriptDir 'skills'
Copy-Item -Path (Join-Path $SkillsSource '*') -Destination $SkillsTarget -Recurse -Force
$SkillCount = (Get-ChildItem -Path $SkillsTarget -Directory).Count
Write-Host "    installed skills/ ($SkillCount skill directories present)"

Write-Host ""
Write-Host "================================================================"
Write-Host "  Claude Code Starter Pack installed."
Write-Host "================================================================"
Write-Host ""
Write-Host "NEXT STEP (required):"
Write-Host "  Open ~/.claude/CLAUDE.md and replace the '## 关于我' section"
Write-Host "  with your own profile (role / team / current project / end user /"
Write-Host "  what you want the AI to focus on)."
Write-Host ""
Write-Host "Optional cleanup:"
Write-Host "  - Disable a skill : Remove-Item -Recurse ~/.claude/skills/<name>"
Write-Host "  - Feishu skills need 'lark-cli auth login' before use."
Write-Host ""
