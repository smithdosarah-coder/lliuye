#!/usr/bin/env bash
# Claude Code Starter Pack — installer (bash/zsh)
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="${HOME}/.claude"

echo "==> Installing Claude Code Starter Pack to: ${TARGET}"
mkdir -p "${TARGET}"

# Backup existing CLAUDE.md if present
if [[ -f "${TARGET}/CLAUDE.md" ]]; then
  TS="$(date +%Y%m%d_%H%M%S)"
  BACKUP="${TARGET}/CLAUDE.md.backup.${TS}"
  cp "${TARGET}/CLAUDE.md" "${BACKUP}"
  echo "    backed up existing CLAUDE.md -> ${BACKUP}"
fi

# Install new CLAUDE.md
cp "${SCRIPT_DIR}/CLAUDE.md" "${TARGET}/CLAUDE.md"
echo "    installed CLAUDE.md"

# Install skills (merge-overwrite)
mkdir -p "${TARGET}/skills"
if command -v rsync >/dev/null 2>&1; then
  rsync -a "${SCRIPT_DIR}/skills/" "${TARGET}/skills/"
else
  cp -r "${SCRIPT_DIR}/skills/." "${TARGET}/skills/"
fi
SKILL_COUNT="$(find "${TARGET}/skills" -mindepth 1 -maxdepth 1 -type d | wc -l | tr -d ' ')"
echo "    installed skills/ (${SKILL_COUNT} skill directories present)"

cat <<'DONE'

================================================================
  Claude Code Starter Pack installed.
================================================================

NEXT STEP (required):
  Open ~/.claude/CLAUDE.md and replace the "## 关于我" section
  with your own profile (role / team / current project / end user /
  what you want the AI to focus on).

Optional cleanup:
  - Disable a skill : rm -rf ~/.claude/skills/<name>/
  - Disable PUA set : rm -rf ~/.claude/skills/{pua*,mama,yes,shot,pro}
  - Feishu skills need `lark-cli auth login` before use.

DONE
