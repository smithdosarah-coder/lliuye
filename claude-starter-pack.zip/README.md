# Claude Code Starter Pack

一套"开箱即用"的 Claude Code 全局配置：硬规则 CLAUDE.md + 72 个精选 skill。解决新环境/新同事"从零配置半天还不知道装哪些"的问题。

## 这是什么

- `CLAUDE.md` — 全局硬规则（第一性原理 / 方案先行 / 交互设计 / Skill 触发映射）。**「关于我」段留空待你填写**，其他段直接用。
- `skills/` — 72 个 skill 目录，覆盖网页抓取、浏览器自动化、代码探索、系统调试、方案规划、并行调度、飞书全家桶、Office 文档处理等。
- `install.sh` / `install.ps1` — 一键安装脚本（bash/zsh 走 sh，PowerShell 走 ps1）。

## 安装

```bash
# Linux / macOS / Git Bash (Windows)
bash install.sh

# PowerShell (Windows)
powershell -ExecutionPolicy Bypass -File install.ps1
```

安装后**第一件事**：打开 `~/.claude/CLAUDE.md`，把「关于我」段替换为你自己的信息（角色、团队、主攻项目、终端客户、你想让 AI 重点关注的维度）。

## Skill 分层清单

### 核心必用（16 个）— 按 CLAUDE.md 触发映射表的硬路由直接命中
| Skill | 场景 |
| --- | --- |
| `web-access` | 抓反爬/登录态/JS 渲染后的网页（公众号、小红书、后台） |
| `browser-automation` | 真实浏览器点击/填表/截图/下载 |
| `webapp-testing` | 本地 webapp 端到端测试 |
| `smart-explore` | 接手陌生 repo、大范围代码定位（tree-sitter AST 搜索） |
| `systematic-debugging` | 任何 bug / 测试失败 / 未预期行为的起点 |
| `verification-before-completion` | 宣布"完成"前的最后一道闸 |
| `make-plan` | 中等以上任务的方案规划（方案先行原则） |
| `writing-plans` | 结构化写多阶段实施计划 |
| `executing-plans` | 执行已写好的分阶段计划 |
| `do` | 分 phase 派 subagent 执行计划 |
| `dispatching-parallel-agents` | 2+ 独立子任务的并行分发 |
| `codex` | 把大批量机械脏活甩给 Codex CLI |
| `receiving-code-review` | 收到 review 反馈时的结构化处理 |
| `requesting-code-review` | 自己请求 review 时的自查 + 组织 |
| `skill-creator` | 新建/改造 skill |
| `writing-skills` | 写 skill 的规范与校验 |

### 按需开启
- **PUA 系列（8 个）**：`pua` / `pua-en` / `pua-ja` / `pua-loop` / `mama` / `yes` / `shot` / `pro`。中国式老板/日企/美式 PIP/夸夸模式切换，用于给 AI 加压穷尽方案。**不喜勿用，删对应目录即可**。
- **设计类**：`canvas-design` / `algorithmic-art` / `brand-guidelines` / `frontend-design` / `theme-factory` / `slack-gif-creator` / `web-artifacts-builder` / `timeline-report` / `shot`。面向设计产出、品牌化、前端美化等场景。
- **职级人设**：`p7` / `p9` / `p10`。高级工程师 / TL / CTO 三套视角切换。
- **文档/office**：`docx` / `xlsx` / `pptx` / `pdf` — 原生处理 Office 四件套，禁止 `python-docx` 裸写。
- **开发流程**：`test-driven-development` / `subagent-driven-development` / `finishing-a-development-branch` / `using-git-worktrees` / `template-skill` / `mcp-builder` / `using-superpowers` / `doc-coauthoring` / `brainstorming` / `internal-comms` / `simplify` / `loop` / `schedule` / `update-config` / `keybindings-help` / `mem-search`。
- **其他集成**：`claude-api`（带 prompt caching 的 SDK 开发）。

### 需自配 token（19 个）
**飞书全家桶**（使用前需 `lark-cli auth login`）：
`lark-shared` / `lark-mcp` / `lark-doc` / `lark-drive` / `lark-wiki` / `lark-sheets` / `lark-base` / `lark-im` / `lark-calendar` / `lark-contact` / `lark-event` / `lark-mail` / `lark-minutes` / `lark-task` / `lark-vc` / `lark-whiteboard` / `lark-openapi-explorer` / `lark-skill-maker` / `lark-workflow-meeting-summary` / `lark-workflow-standup-report` / `feishu-calendar`。

**其他**：
- `codex` — 需配置 Codex CLI 和对应 API key。

未登录飞书/未配 Codex 时这些 skill 不会触发，可放心保留；不用则 `rm -rf skills/lark-*` 删掉。

## 定制指引

| 我想要 | 怎么做 |
| --- | --- |
| 改「关于我」 | 编辑 `~/.claude/CLAUDE.md` 顶部 |
| 关掉某个 skill | `rm -rf ~/.claude/skills/<name>/` |
| 关掉整个 PUA 系列 | `rm -rf ~/.claude/skills/pua* ~/.claude/skills/mama ~/.claude/skills/yes ~/.claude/skills/shot ~/.claude/skills/pro` |
| 只保留核心必用 | 参考上表保留 16 个目录，其余删 |
| 升级 skill | 重跑 `install.sh` / `install.ps1` 会覆盖（旧 `CLAUDE.md` 自动备份） |

## 原有配置的保护

`install.sh` 和 `install.ps1` 都会在覆盖前检查 `~/.claude/CLAUDE.md` 是否存在：存在则重命名为 `CLAUDE.md.backup.<timestamp>`，再写入新版。skills 目录是合并覆盖（同名 skill 被新版替换，独有 skill 保留）。

如果你对原有配置有严重依赖，先手动 `cp -r ~/.claude ~/.claude.fullbackup`。
